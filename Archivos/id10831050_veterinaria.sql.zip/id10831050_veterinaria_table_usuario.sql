
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `login` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `clave` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `correo` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `telefono` varchar(15) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `nombre`, `login`, `clave`, `correo`, `telefono`) VALUES
(1, 'SCOOBYDOOO', 'veterinaria', '1234', 'veteri_scooby@hotmail.com', '09940228546'),
(14, 'Evelyn', 'azueve', 'eve27', 'azueve96_azu@outlook.com', '0961399210'),
(16, 'Deli Molen', 'Delia', 'panes', 'aguirre1902@outlook.com', '0994028656'),
(17, 'edison', 'edison07', 'edison07', 'ediisonaam0796@gmail.com', '0982437034'),
(18, 'javier', 'javiersan', 'onepiece666', 'anthony-105j@hotmail.com', '0982850655'),
(19, 'liss', 'liskat', 'senosculo', 'liskat17@hotmail.com', '0978627802'),
(23, 'sauro', 'sauro', '1809', 'jaque_mate_2016@outlook.com', '0961201879');
