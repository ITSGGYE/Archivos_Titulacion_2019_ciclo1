
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`id`, `nombre`, `descripcion`) VALUES
(1, 'Collar para Perros', 'Marca: Ruffawear\r\nTodos los Tamaños\r\nVariedad de Diseños'),
(2, 'Comida para Perro', 'Raza: Mediana\r\nPro-Can\r\nSano Crecimiento'),
(3, 'SHAMPOO', 'SHAMPOO-MEDICADO\r\nUSO 1VEZ A LA SEMANA\r\nVALOR $10'),
(4, 'Collar para Gatos ', 'Marca: Ruffwear\r\nColores: Negro, Rosado, Morado\r\n'),
(5, 'Shampoo para Mascotas', 'Marca: Bayer\r\nUso en Perros y Gatos '),
(6, 'Shampoo  Medicado para Gatos', 'Marca: Bayer\r\nUso segun Receta Medica ');
