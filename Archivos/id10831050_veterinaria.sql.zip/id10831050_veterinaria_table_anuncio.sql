
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `anuncio`
--

CREATE TABLE `anuncio` (
  `id` int(11) NOT NULL,
  `escrito` text COLLATE utf8_unicode_ci NOT NULL,
  `estado` varchar(11) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'a'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `anuncio`
--

INSERT INTO `anuncio` (`id`, `escrito`, `estado`) VALUES
(1, 'Nueva campaña de Esterilización para Gatas \r\ncon el 10% de Descuento ', 'a'),
(2, 'Promocion 2x1 en Baño para Perros Pequeños\r\n', 'a'),
(3, 'Descuentos en Vacunas de Desparasitante para Gatos o Perros ', 'a'),
(12, 'Promociones en Baño Medicado  al 10% de Descuento', 'a'),
(13, 'DescuentosEn Baño Medicado Con precio de 15.00$', 'a'),
(14, 'Descuento del 10% en vacunas', 'a'),
(15, 'Feria de perros', 'a');
